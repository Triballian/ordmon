Certain sites do not like being scraped, to get around this python needs to pretend to be a browser.
You need to download the program chrome driver http://chromedriver.storage.googleapis.com/index.html
I use 2.9 win32
just place chromedriver.exe into the same directory as gormonsel.exe
Instructions:

You need to be logged after clickin on the Open log Page button in order for it to work. After the first time you log in, it should be able to run automatically,
you can open up a new tab and use the c-cex website normally but you don't want to work on the first tab the app opens
any questions or comments you can contact me at: 
noe@stakeco.in